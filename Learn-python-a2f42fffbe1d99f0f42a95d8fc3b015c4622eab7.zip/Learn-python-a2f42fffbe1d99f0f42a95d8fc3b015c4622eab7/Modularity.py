#coding: utf-8

import math

result = math.sqrt(100)

print(result)

square = math.sinh(1)
cos = math.cos(1)

print(square, cos)

import functions.Function as Function 

Function.Maths(4, 1, 3)